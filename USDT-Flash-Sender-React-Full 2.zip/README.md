
# 📄 README — USDT Flash Sender (React)

## 🚀 מה זה?
מערכת לשליחת USDT בבלוקצ׳יין TRON עם React ו-TronWeb.

## ✅ איך מריצים מקומית?
1. התקן Node.js
2. בתיקייה:
   npm install
   npm start

## ⚡ איך מעלים ל-Vercel?
1. פתח Repo ב-GitHub
2. העלה את כל הקבצים
3. חבר ל-Vercel
4. בחר framework = Create React App
5. לחץ Deploy
6. קבל לינק!

בהצלחה 🚀
